<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ProjectSheetController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/projects', [ProjectController::class, 'index']);
Route::get('/projects/{projectId}/keyphrases', [ProjectController::class, 'getKeyPh']);
Route::get('/projects/{projectId}/rankings', [ProjectController::class, 'getRanking']);
Route::get('/test', function(){
    //return (new ProjectSheetController(2015))->download('test.xlsx');
    //Excel::store(new ProjectSheetController(collect(['test'])), date('Y-m-d').'-'.uniqid().'-keyReports.xlsx');
    
    echo asset("storage/2022-07-18-62d5cbd4679ea-keyReports.xlsx");
});