<?php

return [

    'apikey' => env('ANT_RANK_APIKEY', '')
];
